const API_BASE="https://YOUR-RENDER-SERVICE.onrender.com";
const form=document.querySelector("#form"), input=document.querySelector("#url"), btn=document.querySelector("#btn"), status=document.querySelector("#status"), result=document.querySelector("#result");
form.addEventListener("submit",async e=>{e.preventDefault();btn.disabled=true;status.textContent="Getting video information...";result.classList.add("hidden");
try{const r=await fetch(`${API_BASE}/api/info?url=${encodeURIComponent(input.value.trim())}`);const d=await r.json();if(!r.ok)throw Error(d.error||"Request failed");
result.innerHTML=`<b>${esc(d.title||"Video")}</b><p>Channel: ${esc(d.uploader||"Unknown")}<br>Duration: ${fmt(d.duration)}</p><a href="${esc(d.webpage_url||input.value)}" target="_blank" rel="noopener">Open on YouTube</a>`;result.classList.remove("hidden");status.textContent="Done."}
catch(e){status.textContent=e.message}finally{btn.disabled=false}});
function fmt(s){if(!Number.isFinite(s))return"Unknown";s=Math.floor(s);let h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return h?`${h}:${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`:`${m}:${String(x).padStart(2,"0")}`}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}