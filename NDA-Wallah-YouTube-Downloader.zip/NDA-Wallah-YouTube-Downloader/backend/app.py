import os
from flask import Flask,request,jsonify
from flask_cors import CORS
import yt_dlp

app=Flask(__name__)
CORS(app)

@app.get("/")
def home():
    return jsonify(ok=True,service="NDA Wallah YouTube Downloader API")

@app.get("/api/info")
def info():
    url=request.args.get("url","").strip()
    if not url:return jsonify(error="Missing YouTube URL"),400
    opts={"quiet":True,"no_warnings":True,"skip_download":True,"noplaylist":True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            data=ydl.extract_info(url,download=False)
        return jsonify(title=data.get("title"),uploader=data.get("uploader"),duration=data.get("duration"),thumbnail=data.get("thumbnail"),webpage_url=data.get("webpage_url",url))
    except Exception as e:
        return jsonify(error=str(e)),500

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","10000")))