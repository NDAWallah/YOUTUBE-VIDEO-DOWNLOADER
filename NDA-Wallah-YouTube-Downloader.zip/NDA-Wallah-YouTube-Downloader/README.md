# NDA Wallah — YouTube Video Downloader

## Structure
- `frontend/` — GitHub Pages website
- `backend/` — Flask API for Render

## Render
Root Directory: `backend`
Build Command: `pip install -r requirements.txt`
Start Command: `gunicorn app:app`

Then put the Render URL into `frontend/script.js` as `API_BASE`.

The first version retrieves public video metadata only. Use it for content you own or have permission to download and follow YouTube's terms and applicable law.
